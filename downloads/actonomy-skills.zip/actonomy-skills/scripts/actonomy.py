#!/usr/bin/env python3
"""Source-checkout entry point for Act-onomy's independent tools."""

import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
COMMANDS = {
    'parse': ('tools/trace-qualitative-analyst/scripts/parse_trajectory.py', 'Parse a SWE-agent message-list JSON'),
    'parse-chat': ('tools/human-trace-qualitative-analyst/scripts/parse_chat_trajectory.py', 'Parse a Claude Code session JSONL'),
    'render': ('tools/trace-qualitative-analyst/scripts/render_artifact.py', 'Render annotated JSON as interactive HTML'),
    'check': ('tools/extension-tool/scripts/check_consistency.py', 'Check the local codebook and its dependents'),
    'codebook': ('tools/extension-tool/scripts/regenerate_docs.py', 'Generate the full codebook Markdown'),
    'crosswalk': ('examples/crosswalk/crosswalk.py', 'Reproduce the MAST and CoALA mappings'),
}


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    parser = argparse.ArgumentParser(
        description=__doc__,
        epilog='Run COMMAND --help for its options. Parsing creates a skeleton; annotation is a separate step.',
    )
    subparsers = parser.add_subparsers(dest='command', required=True)
    for name, (_, description) in COMMANDS.items():
        subparsers.add_parser(name, help=description, add_help=False)
    subparsers.add_parser('demo', help='Render the bundled annotated example', add_help=False)
    if not argv:
        parser.print_help()
        return 0
    args = parser.parse_args(argv[:1])
    forwarded = argv[1:]
    if args.command == 'demo':
        demo = argparse.ArgumentParser(description='Render the bundled pylint example without an LLM or API key.')
        demo.add_argument('--output', type=Path, default=ROOT / 'outputs/demo.html')
        options = demo.parse_args(forwarded)
        options.output.parent.mkdir(parents=True, exist_ok=True)
        script = COMMANDS['render'][0]
        forwarded = [str(ROOT / 'tools/trace-qualitative-analyst/assets/example_pylint_5859.json'),
                     '--output', str(options.output)]
    else:
        script = COMMANDS[args.command][0]
    # Preserve the caller's working directory for relative input/output paths.
    return subprocess.run([sys.executable, str(ROOT / script), *forwarded], check=False).returncode


if __name__ == '__main__':
    sys.exit(main())
