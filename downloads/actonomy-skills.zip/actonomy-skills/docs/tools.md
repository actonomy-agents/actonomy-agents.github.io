# Tools

For trajectory analysis, follow the [four-step skill workflow](quickstart.md). The assistant supplies the annotations and interpretation; the command-line helpers do not analyze trajectories on their own.

The common helper entry point is `python3 scripts/actonomy.py COMMAND`. It dispatches to the existing tool scripts with the same Python interpreter and preserves the caller's working directory. Input/output paths are relative to that directory. Each underlying script remains directly runnable.

| Command | Input | Output |
| --- | --- | --- |
| `demo` | Bundled annotated pylint example | `outputs/demo.html` by default |
| `parse` | SWE-agent message-list JSON | Annotation skeleton; default `<stem>.annotated.json` |
| `parse-chat` | Claude Code session JSONL | Annotation skeleton; default `<stem>.skeleton.json` |
| `render` | Annotated JSON | HTML; default `<instance>-trajectory-analysis.html` in the current directory |
| `check` | Local codebook and dependents | Console report; use `--json` for JSON |
| `codebook` | Canonical CSVs | `outputs/codebook_v4.2.md` by default |
| `crosswalk` | Taxonomy CSV and declared mappings | Tables under `outputs/crosswalk/` by default |

Run `python3 scripts/actonomy.py COMMAND --help` for options. Use `--output` to keep parse/render products in `outputs/`; create its parent directory first. Existing output files are overwritten by the underlying tools.

## Skill bundles

| Bundle | Purpose |
| --- | --- |
| [trace-qualitative-analyst](../tools/trace-qualitative-analyst/SKILL.md) | Quote-level annotation and interpretation of agent traces |
| [human-trace-qualitative-analyst](../tools/human-trace-qualitative-analyst/SKILL.md) | Human interactions interleaved with agent behavior |
| [discovery-qualitative-analyst](../tools/discovery-qualitative-analyst/SKILL.md) | Extract behaviors from papers and propose codebook revisions |
| [extension-tool](../tools/extension-tool/SKILL.md) | Validate and propagate accepted codebook changes |

Each bundle includes a `SKILL.md`, supporting references, and scripts. An agent can read the file directly from this checkout. These files do not automatically register themselves in an assistant or supply its tools. The human-interaction skill needs the trace skill beside it because they share a codebook and renderer.

Personal skill installations should be maintained in the shared skill-library source and registered through that library's workflow. Repository bundles are distributable project artifacts; running the CLI does not install or overwrite personal skills. To compare a known trace-skill installation, pass its path explicitly:

```bash
python3 scripts/actonomy.py check --runtime-skill /path/to/trace-qualitative-analyst
```

## Optional discovery document builders

Only the discovery workflow's Word document builders require Node.js and `docx`:

```bash
npm ci --prefix tools/discovery-qualitative-analyst/scripts
npm run check --prefix tools/discovery-qualitative-analyst/scripts
node tools/discovery-qualitative-analyst/scripts/build_f1_extraction_docx.js \
  f1_spec.json outputs/f1_extraction.docx
```

Input specifications are documented in [spec-schema.md](../tools/discovery-qualitative-analyst/scripts/spec-schema.md). The F2 and F3 builders follow the same invocation pattern. The skills also describe host-provided document validation tools; availability depends on the agent environment. Python-only use does not require npm.

