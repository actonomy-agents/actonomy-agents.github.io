# Act-onomy skills 使用说明

下载包包含 4 个 skill、codebook（10 个动作、46 个子动作、120 个叶类别）、
解析和渲染脚本、报告模板、示例和许可证。

## 下载后使用

1. 解压 ZIP，保留整个 `actonomy-skills/` 目录。
2. 在支持读取本地文件、执行脚本的 coding agent 中打开该目录，使用该 agent 已配置的模型。
3. 放入自己的轨迹文件，把下面的提示词发给 agent。

普通 SWE-agent 轨迹：

> 阅读 `tools/trace-qualitative-analyst/SKILL.md`，按照该 skill 分析
> `my-trajectory.json`。使用 codebook 逐条标注，并保留准确的原文证据。
> 将完整标注 JSON 和交互 HTML 报告保存到 `outputs/`。

含真人输入的 Claude Code 会话：

> 阅读 `tools/human-trace-qualitative-analyst/SKILL.md`，分析
> `my-session.jsonl`，区分人类输入与 agent 行为，将标注和 HTML 报告保存到 `outputs/`。

把示例文件名替换为自己的文件名。SWE-agent 解析器支持含 `role`、`text` 的消息数组；
其他 JSON 结构需要适配。会话解析器支持 Claude Code 原生 JSONL。

这种显式读取文件的用法无需全局安装。若要注册为 agent 自动发现的 skill，
请遵循该 agent 的安装说明并保留目录间的相对关系：人机交互 skill 依赖同级的基础轨迹 skill，
扩展工具依赖下载包内的 `data/taxonomy/`。

## 选择 skill

- `trace-qualitative-analyst`：分析 agent 轨迹，生成带原文证据的交互报告。
- `human-trace-qualitative-analyst`：分析含真人输入的会话。
- `discovery-qualitative-analyst`：依据论文提取行为、提出 codebook 修订，生成 Word 文档。
- `extension-tool`：对已接受的 codebook 修改执行一致性检查和维护。

论文分析需提供论文和现有 codebook，可使用包内 `data/taxonomy/taxonomy.md`。
修改本地下载包不会更新上游项目。

## 环境与验证

轨迹解析和 HTML 渲染需要 Python 3.10+，无需安装 Python 依赖。
标注和解释由 agent 调用其已配置的模型完成，`actonomy.py` 本身不调用模型。
只有论文分析的 Word 生成器需要 Node.js、npm 和本地依赖：

```bash
npm ci --prefix tools/discovery-qualitative-analyst/scripts
```

在解压后的目录执行：

```bash
python3 scripts/actonomy.py check
python3 scripts/actonomy.py demo
```

打开 `outputs/demo.html` 可验证渲染环境。这使用已标注样例，分析自己的新轨迹仍需上面的 agent 步骤。
完整英文说明见 `README.md`；代码和 codebook 的许可证分别见 `LICENSE` 和 `LICENSE-codebook`。
