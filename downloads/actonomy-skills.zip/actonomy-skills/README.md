# Act-onomy skills

Four skills for analyzing agent behavior with the Act-onomy codebook:
**10 actions, 46 subactions, and 120 leaf categories**.

## Start with your own trajectory

1. Extract this ZIP and keep the `actonomy-skills/` folder together.
2. Open that folder in a coding agent that can read local files and run scripts.
   Use your existing model connection in that agent.
3. Add your trajectory file and send the appropriate prompt below. The agent reads
   the skill, parses the input, performs the annotation, and renders the report.

For a SWE-agent message-list JSON:

> Read `tools/trace-qualitative-analyst/SKILL.md` and use it to analyze
> `my-trajectory.json`. Follow the codebook and ground each label in an exact
> quote. Save the completed annotation and HTML report under `outputs/`.

For a Claude Code session JSONL containing human messages:

> Read `tools/human-trace-qualitative-analyst/SKILL.md` and use it to analyze
> `my-session.jsonl`. Include the human interactions and agent behavior. Save the
> completed annotation and HTML report under `outputs/`.

Replace the example filename with your own file. The SWE-agent parser expects an
array of messages with `role` and `text`; other formats need an adapter. The chat
parser expects Claude Code native session JSONL.

No global installation is required for this explicit file-based workflow. If you
register the skills with your agent for reuse, preserve their relative locations:
the human-interaction skill uses the sibling trace skill, and the extension tool
uses the bundled `data/taxonomy/`. Refer to your agent's installation instructions.

## Choose a skill

| Skill | Input | Result |
| --- | --- | --- |
| `tools/trace-qualitative-analyst/SKILL.md` | Agent trajectory | Quote-level annotations and an interactive HTML report |
| `tools/human-trace-qualitative-analyst/SKILL.md` | Human–agent session | An HTML report with separate human interaction events |
| `tools/discovery-qualitative-analyst/SKILL.md` | Agent paper and existing codebook | Extraction, refinement, and proposed next-version codebook documents |
| `tools/extension-tool/SKILL.md` | Accepted codebook changes | Consistency checks and updates to dependent artifacts |

For discovery, ask the agent to read that skill and analyze your paper against
`data/taxonomy/taxonomy.md`. For maintenance, ask it to read the extension skill
and check this extracted toolkit before editing an accepted change. Changes to
this local copy do not update the upstream project.

## Requirements

- **Python 3.10+** for parsing, rendering, codebook checks, and crosswalks. These
  commands use the standard library and need no Python package installation.
- A coding agent with a configured model connection performs annotation and
  interpretation. The Python commands do not call an LLM.
- **Node.js and npm** are only needed for the discovery skill's Word builders.
  From this folder, install their local dependency once:

  ```bash
  npm ci --prefix tools/discovery-qualitative-analyst/scripts
  ```

## Check the installation without a model

Run these commands from the extracted `actonomy-skills/` folder:

```bash
python3 scripts/actonomy.py check
python3 scripts/actonomy.py demo
```

Open `outputs/demo.html`. This checks the local renderer with an existing
annotation; it does not analyze a new trajectory.

For your own data, the command-line stages are:

```bash
mkdir -p outputs
python3 scripts/actonomy.py parse my-trajectory.json --output outputs/trace.skeleton.json
# Have your agent follow the skill and save a completed outputs/trace.annotated.json.
python3 scripts/actonomy.py render outputs/trace.annotated.json --output outputs/report.html
```

Use `parse-chat` instead of `parse` for a supported human–agent session. Review
warnings and verify the evidence before using the report. Open the resulting
HTML in your browser; a website server is not required.

## Contents and attribution

This bundle includes all four skill folders, their scripts, templates, references,
worked examples, the canonical taxonomy and its development snapshots, the common
`scripts/actonomy.py` entry point, and the crosswalk examples. Keep these folders
together so relative paths continue to work.

`manifest.json` records a SHA-256 hash for each bundled file. The accompanying
website download manifest also records the ZIP hash and size. Local dependencies,
caches, personal settings, and unpublished working data are excluded.

Source project: https://github.com/gaojie058/Act-onomy

Code and skill instructions: MIT (`LICENSE`). Codebook and labeled data:
CC BY 4.0 (`LICENSE-codebook`). Third-party examples retain their original
attribution. See `CITATION.cff` for the research citation.
