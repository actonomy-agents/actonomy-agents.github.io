# Bundled taxonomy

This download includes the canonical taxonomy and development snapshots: 10 actions, 46 subactions, and 120 leaf categories.

Research corpora are available in the source project: https://github.com/gaojie058/Act-onomy
